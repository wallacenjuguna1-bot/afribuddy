import React, { useMemo, useState } from "react";

// ---------- Helper Data ----------
const DESTINATIONS = [
  { code: "KE", name: "Kenya", cities: ["Nairobi", "Mombasa", "Naivasha", "Diani"], blurb: "Markets, wildlife, nightlife. From Nairobi city tours to coastal chill in Diani.", dailyRate: 95 },
  { code: "UG", name: "Uganda", cities: ["Kampala", "Entebbe", "Jinja", "Fort Portal"], blurb: "Vibrant Kampala, Nile source day trips, crater lakes, cultural nights.", dailyRate: 85 },
  { code: "TZ", name: "Tanzania", cities: ["Dar es Salaam", "Zanzibar", "Arusha", "Moshi"], blurb: "Island vibes in Zanzibar, food tours, and city nights in Dar.", dailyRate: 95 },
  { code: "RW", name: "Rwanda", cities: ["Kigali", "Musanze", "Gisenyi"], blurb: "Clean, calm, and creative—art tours, coffee, and lakeside sunsets.", dailyRate: 110 },
  { code: "BI", name: "Burundi", cities: ["Bujumbura", "Gitega"], blurb: "Tanganyika shoreline, music, and markets with a local friend.", dailyRate: 80 },
  { code: "CD", name: "Congo (DRC)", cities: ["Kinshasa", "Goma", "Lubumbashi"], blurb: "Urban culture, riverfront scenes, and translation/hosting support.", dailyRate: 120 },
];

const GUIDES = [
  { id: "g1", name: "Brian W.", city: "Nairobi", country: "Kenya", languages: ["English", "Swahili"], specialties: ["Markets", "Nightlife", "Photo Walks"], rating: 4.9, rate: 95, img: "https://images.unsplash.com/photo-1529669851596-ba9a554eb6b6?q=80&w=1400&auto=format&fit=crop" },
  { id: "g2", name: "Cathy N.", city: "Kigali", country: "Rwanda", languages: ["English", "French", "Kinyarwanda"], specialties: ["Art & Coffee", "Museums", "Hiking"], rating: 4.8, rate: 110, img: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=1400&auto=format&fit=crop" },
  { id: "g3", name: "Sam T.", city: "Zanzibar", country: "Tanzania", languages: ["English", "Swahili", "German"], specialties: ["Food Tours", "Old Town", "Beaches"], rating: 4.7, rate: 95, img: "https://images.unsplash.com/photo-1529665253569-6d01c0eaf7b6?q=80&w=1400&auto=format&fit=crop" },
];

const FAQ = [
  { q: "What exactly is a companion-guide?", a: "A friendly, verified local who plans your day with you, shows you around, translates when needed, and stays with you during the booked hours. We are not selling package tours—we host, guide, and support your plans." },
  { q: "How do payments work?", a: "You pay a 30–50% deposit online to secure the date. The remaining balance is paid on the day (card/cash/mobile money depending on city)." },
  { q: "Is it safe?", a: "We verify IDs for guides and ask both guests and guides to meet in public first. We also provide a safety contact you can share with a friend." },
  { q: "Refunds & cancellations?", a: "Full refund up to 72h before the start. 50% within 72–24h. No-shows are non-refundable. If a guide cancels, you get a full refund." },
];

const WHATSAPP_E164 = "+254775333307";
const BOOKING_EMAIL = "brianndungu45@gmail.com";

function encodeWhatsApp(msg) {
  return `https://wa.me/${WHATSAPP_E164}?text=${encodeURIComponent(msg)}`;
}

function Hero({ onPlan }) {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-emerald-900 via-emerald-800 to-emerald-700 text-white">
      <div className="absolute inset-0 opacity-30" style={{ backgroundImage: "url(https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=2400&auto=format&fit=crop)", backgroundSize: "cover", backgroundPosition: "center" }} />
      <div className="relative mx-auto max-w-6xl px-4 py-24">
        <div className="max-w-3xl">
          <span className="inline-block rounded-full bg-white/10 px-3 py-1 text-sm backdrop-blur">ID‑verified guides • Flexible refunds • 24/7 support</span>
          <h1 className="mt-6 text-4xl font-bold leading-tight sm:text-5xl">Travel like you’ve got friends in town</h1>
          <p className="mt-4 text-lg text-emerald-50">Local companion-guides across Kenya, Uganda, Tanzania, Rwanda, Burundi & Congo (DRC). Safer, friendlier, stress‑free.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <button onClick={onPlan} className="rounded-2xl bg-white px-5 py-3 font-semibold text-emerald-900 shadow hover:shadow-lg">Plan my trip</button>
            <a href={encodeWhatsApp("Hi! I’d like to plan a trip.")} target="_blank" rel="noreferrer" className="rounded-2xl border border-white/70 px-5 py-3 font-semibold hover:bg-white/10">Chat on WhatsApp</a>
          </div>
          <div className="mt-10 grid grid-cols-2 gap-6 sm:grid-cols-4">
            {[{ n: "6", t: "Countries" }, { n: "20+", t: "Cities" }, { n: "4.8★", t: "Avg. rating" }, { n: "24/7", t: "Support" }].map((k) => (
              <div key={k.t} className="rounded-2xl bg-white/10 p-4 text-center backdrop-blur">
                <div className="text-2xl font-bold">{k.n}</div>
                <div className="text-sm opacity-90">{k.t}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function HowItWorks() {
  const steps = [
    { title: "Tell us your vibes", text: "Pick country, dates, and what you enjoy—food, markets, nightlife, hikes." },
    { title: "Match with a guide", text: "Choose a profile or let us match you. See languages, rate, and reviews." },
    { title: "Reserve with deposit", text: "Secure your date with 30–50% deposit. Instant WhatsApp confirmation." },
    { title: "Enjoy your day", text: "Meet in public first, finalize the plan, and explore together." },
  ];
  return (
    <section id="how" className="mx-auto max-w-6xl px-4 py-16">
      <h2 className="text-3xl font-bold">How it works</h2>
      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {steps.map((s, i) => (
          <div key={s.title} className="rounded-2xl border border-emerald-100 bg-white p-6 shadow-sm">
            <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-full bg-emerald-600/10 font-bold text-emerald-700">{i + 1}</div>
            <h3 className="font-semibold">{s.title}</h3>
            <p className="mt-2 text-sm text-gray-600">{s.text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function Destinations() {
  return (
    <section id="destinations" className="bg-emerald-50/60 py-16">
      <div className="mx-auto max-w-6xl px-4">
        <h2 className="text-3xl font-bold">Destinations</h2>
        <p className="mt-2 text-gray-700">Choose a country to see popular cities, sample day ideas, and guide rates.</p>
        <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {DESTINATIONS.map((d) => (
            <div key={d.code} className="flex flex-col justify-between rounded-2xl border border-emerald-100 bg-white p-6 shadow-sm">
              <div>
                <h3 className="text-xl font-semibold">{d.name}</h3>
                <p className="mt-2 text-sm text-gray-600">{d.blurb}</p>
                <div className="mt-3 text-sm text-gray-700"><span className="font-medium">Cities:</span> {d.cities.join(", ")}</div>
                <div className="mt-1 text-sm text-gray-700"><span className="font-medium">From:</span> ${d.dailyRate}/day</div>
                <div className="mt-4 overflow-hidden rounded-xl border border-emerald-100">
                  <iframe
                    title={`Map of ${d.name}`}
                    src={`https://www.google.com/maps?q=${encodeURIComponent(d.name)}&output=embed`}
                    width="100%"
                    height="180"
                    style={{ border: 0 }}
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    allowFullScreen
                  />
                </div>
              </div>
              <div className="mt-6">
                <a href="#book" className="inline-block rounded-xl bg-emerald-700 px-4 py-2 text-white hover:bg-emerald-800">Plan here</a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function GuideCard({ g }) {
  return (
    <div className="rounded-2xl border border-emerald-100 bg-white shadow-sm">
      <div className="aspect-[16/10] w-full overflow-hidden rounded-t-2xl">
        <img src={g.img} alt={g.name} className="h-full w-full object-cover"/>
      </div>
      <div className="p-5">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-semibold">{g.name}</h3>
            <p className="text-sm text-gray-600">{g.city}, {g.country}</p>
          </div>
          <div className="text-sm font-semibold">{g.rating}★</div>
        </div>
        <div className="mt-3 text-sm text-gray-700"><span className="font-medium">Languages:</span> {g.languages.join(", ")}</div>
        <div className="mt-1 text-sm text-gray-700"><span className="font-medium">Specialties:</span> {g.specialties.join(", ")}</div>
        <div className="mt-4 flex items-center justify-between">
          <div className="text-sm"><span className="font-semibold">${g.rate}</span>/day</div>
          <a className="rounded-xl border border-emerald-700 px-3 py-1.5 text-sm font-semibold text-emerald-800 hover:bg-emerald-50" href={encodeWhatsApp(`Hi! I'd like to book ${g.name} in ${g.city}.`)} target="_blank" rel="noreferrer">Chat</a>
        </div>
      </div>
    </div>
  );
}

function Guides() {
  return (
    <section id="guides" className="mx-auto max-w-6xl px-4 py-16">
      <h2 className="text-3xl font-bold">Featured guides</h2>
      <p className="mt-2 text-gray-700">All guides are ID‑verified and speak at least English plus one local language.</p>
      <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {GUIDES.map((g) => <GuideCard key={g.id} g={g} />)}
      </div>
    </section>
  );
}

function Pricing() {
  const addOns = [
    { name: "Evening Host (4 hrs)", price: 55 },
    { name: "Airport Pickup", price: 25, note: "city‑dependent" },
    { name: "Photo Walk (2 hrs)", price: 45 },
  ];
  return (
    <section id="pricing" className="bg-white py-16">
      <div className="mx-auto max-w-6xl px-4">
        <h2 className="text-3xl font-bold">Simple pricing</h2>
        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          <div className="rounded-2xl border border-emerald-100 p-6 shadow-sm">
            <h3 className="text-xl font-semibold">City Companion (8 hrs)</h3>
            <p className="mt-2 text-gray-700">From $80–$120/day depending on city and guide. Entrance fees/transport not included.</p>
            <ul className="mt-4 list-disc pl-6 text-sm text-gray-700">
              <li>Plan together over WhatsApp before you arrive</li>
              <li>Meet in public first; adjust the plan live</li>
              <li>Pay 30–50% deposit to secure the date</li>
            </ul>
          </div>
          <div className="rounded-2xl border border-emerald-100 p-6 shadow-sm">
            <h3 className="text-xl font-semibold">Popular add‑ons</h3>
            <ul className="mt-4 divide-y">
              {addOns.map((a) => (
                <li key={a.name} className="flex items-center justify-between py-3 text-sm">
                  <span>{a.name}{a.note ? ` (${a.note})` : ""}</span>
                  <span className="font-semibold">${a.price}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

function Safety() {
  const items = [
    { title: "Guide verification", text: "Government ID on file, live video onboarding, references when available." },
    { title: "Public first meeting", text: "We strongly recommend your first meet in a public, well‑lit place." },
    { title: "Itinerary share", text: "Share your plan + guide contact with a trusted friend in one tap." },
    { title: "Clear policies", text: "Refund, cancellation, and code of conduct are transparent before you pay." },
  ];
  return (
    <section id="safety" className="bg-emerald-50/60 py-16">
      <div className="mx-auto max-w-6xl px-4">
        <h2 className="text-3xl font-bold">Safety & trust</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {items.map((it) => (
            <div key={it.title} className="rounded-2xl border border-emerald-100 bg-white p-6 shadow-sm">
              <h3 className="font-semibold">{it.title}</h3>
              <p className="mt-2 text-sm text-gray-600">{it.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Reviews() {
  const reviews = [
    { name: "Alicia, US", text: "Felt like visiting friends—Brian’s food + market tour made Nairobi easy and fun." },
    { name: "Jon, UK", text: "Smooth airport pickup and great nightlife tips in Dar. Will book again." },
    { name: "Marta, ES", text: "Kigali art tour with coffee tastings—super insightful and safe." },
  ];
  return (
    <section id="reviews" className="mx-auto max-w-6xl px-4 py-16">
      <h2 className="text-3xl font-bold">Traveler love</h2>
      <div className="mt-8 grid gap-6 md:grid-cols-3">
        {reviews.map((r) => (
          <div key={r.name} className="rounded-2xl border border-emerald-100 bg-white p-6 shadow-sm">
            <p className="text-sm text-gray-700">“{r.text}”</p>
            <div className="mt-4 text-sm font-semibold text-gray-900">— {r.name}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Faq() {
  return (
    <section id="faq" className="bg-white py-16">
      <div className="mx-auto max-w-6xl px-4">
        <h2 className="text-3xl font-bold">FAQs</h2>
        <div className="mt-6 divide-y">
          {FAQ.map((f) => (
            <details key={f.q} className="group py-4">
              <summary className="cursor-pointer list-none font-medium group-open:text-emerald-800">{f.q}</summary>
              <p className="mt-2 text-sm text-gray-700">{f.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

function Legal() {
  return (
    <section id="legal" className="bg-emerald-950 py-12 text-emerald-50">
      <div className="mx-auto max-w-6xl px-4 text-sm">
        <div className="grid gap-8 md:grid-cols-3">
          <div>
            <div className="text-lg font-semibold">Policies</div>
            <p className="mt-2 opacity-90">We offer hosting/companion services and do not sell packaged tours. Local regulations may require licensed guides for some activities; where required, we assign licensed partners.</p>
          </div>
          <div>
            <div className="text-lg font-semibold">Refunds & Cancellation</div>
            <ul className="mt-2 list-disc pl-5 opacity-90">
              <li>Full refund up to 72h before start</li>
              <li>50% refund within 72–24h</li>
              <li>No refund for no‑shows</li>
              <li>If a guide cancels, full refund or free rematch</li>
            </ul>
          </div>
          <div>
            <div className="text-lg font-semibold">Privacy</div>
            <p className="mt-2 opacity-90">We collect only what we need to match you with a guide and complete your booking. We never sell your data. You can request deletion anytime.</p>
          </div>
        </div>
        <div className="mt-8 border-t border-white/10 pt-6 opacity-80">© {new Date().getFullYear()} AfriBuddy • Nairobi, Kenya</div>
      </div>
    </section>
  );
}

function BookingForm() {
  const [country, setCountry] = useState("KE");
  const [city, setCity] = useState("");
  const [dates, setDates] = useState("");
  const [hours, setHours] = useState("8");
  const [people, setPeople] = useState("1");
  const [name, setName] = useState("");
  const [whatsApp, setWhatsApp] = useState("");
  const [interests, setInterests] = useState("");
  const destination = useMemo(() => DESTINATIONS.find((d) => d.code === country), [country]);

  const handleWhatsApp = () => {
    const msg = `Hi AfriBuddy!\n\nI'd like to book a companion-guide.\nName: ${name}\nWhatsApp: ${whatsApp}\nCountry: ${destination?.name}\nCity: ${city}\nDates: ${dates}\nHours/day: ${hours}\nPeople: ${people}\nInterests: ${interests}`;
    window.open(encodeWhatsApp(msg), "_blank");
  };

  const handleEmail = () => {
    const subject = encodeURIComponent("AfriBuddy booking request");
    const body = encodeURIComponent(
      `I'd like to book a companion-guide.\n\nName: ${name}\nWhatsApp: ${whatsApp}\nCountry: ${destination?.name}\nCity: ${city}\nDates: ${dates}\nHours/day: ${hours}\nPeople: ${people}\nInterests: ${interests}`
    );
    window.location.href = `mailto:${BOOKING_EMAIL}?subject=${subject}&body=${body}`;
  };

  return (
    <section id="book" className="bg-white py-16">
      <div className="mx-auto max-w-3xl px-4">
        <h2 className="text-3xl font-bold">Plan your trip</h2>
        <p className="mt-2 text-gray-700">Tell us the basics. We’ll reply on WhatsApp with a plan and deposit link.</p>

        <div className="mt-8 grid gap-4">
          <div className="grid gap-2">
            <label className="text-sm font-medium">Country</label>
            <select value={country} onChange={(e) => setCountry(e.target.value)} className="rounded-xl border border-emerald-200 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-600">
              {DESTINATIONS.map((d) => (
                <option key={d.code} value={d.code}>{d.name}</option>
              ))}
            </select>
          </div>

          <div className="grid gap-2">
            <label className="text-sm font-medium">City</label>
            <input value={city} onChange={(e) => setCity(e.target.value)} placeholder={`e.g., ${DESTINATIONS.find(x => x.code===country)?.cities[0] ?? "City"}`} className="rounded-xl border border-emerald-200 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-600"/>
          </div>

          <div className="grid gap-2 sm:grid-cols-2">
            <div className="grid gap-2">
              <label className="text-sm font-medium">Dates</label>
              <input value={dates} onChange={(e) => setDates(e.target.value)} placeholder="e.g., 5–8 Dec" className="rounded-xl border border-emerald-200 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-600"/>
            </div>
            <div className="grid gap-2">
              <label className="text-sm font-medium">Hours per day</label>
              <select value={hours} onChange={(e) => setHours(e.target.value)} className="rounded-xl border border-emerald-200 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-600">
                <option>4</option>
                <option>6</option>
                <option>8</option>
              </select>
            </div>
          </div>

          <div className="grid gap-2">
            <label className="text-sm font-medium">Number of people</label>
            <select value={people} onChange={(e) => setPeople(e.target.value)} className="rounded-xl border border-emerald-200 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-600">
              <option>1</option>
              <option>2</option>
              <option>3</option>
              <option>4</option>
            </select>
          </div>

          <div className="grid gap-2 sm:grid-cols-2">
            <div className="grid gap-2">
              <label className="text-sm font-medium">Your name</label>
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name" className="rounded-xl border border-emerald-200 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-600"/>
            </div>
            <div className="grid gap-2">
              <label className="text-sm font-medium">Your WhatsApp</label>
              <input value={whatsApp} onChange={(e) => setWhatsApp(e.target.value)} placeholder="With country code" className="rounded-xl border border-emerald-200 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-600"/>
            </div>
          </div>

          <div className="grid gap-2">
            <label className="text-sm font-medium">What do you want to do?</label>
            <textarea value={interests} onChange={(e) => setInterests(e.target.value)} placeholder="Food, markets, nightlife, museums, hiking, photography…" rows={4} className="rounded-xl border border-emerald-200 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-600"/>
          </div>

          <div className="mt-2 flex flex-wrap gap-3">
            <button onClick={handleWhatsApp} className="rounded-2xl bg-emerald-700 px-5 py-3 font-semibold text-white hover:bg-emerald-800">Send on WhatsApp</button>
            <button onClick={handleEmail} className="rounded-2xl border border-emerald-700 px-5 py-3 font-semibold text-emerald-800 hover:bg-emerald-50">Email instead</button>
          </div>

          <p className="mt-3 text-xs text-gray-500">By sending, you agree to our Refund & Privacy policies. We’ll reply within a few hours with availability and a deposit link (Stripe/Flutterwave/M-Pesa where supported).</p>
        </div>
      </div>
    </section>
  );
}

function Header() {
  const links = [
    { href: "#how", label: "How it works" },
    { href: "#destinations", label: "Destinations" },
    { href: "#guides", label: "Guides" },
    { href: "#pricing", label: "Pricing" },
    { href: "#safety", label: "Safety" },
    { href: "#faq", label: "FAQs" },
  ];
  return (
    <header className="sticky top-0 z-50 border-b border-emerald-100 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <a href="#" className="flex items-center gap-2">
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-700 text-white">A</span>
          <span className="font-semibold">AfriBuddy</span>
        </a>
        <nav className="hidden gap-6 md:flex">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="text-sm font-medium text-gray-800 hover:text-emerald-700">{l.label}</a>
          ))}
        </nav>
        <a href="#book" className="rounded-xl bg-emerald-700 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-800">Plan my trip</a>
      </div>
    </header>
  );
}

export default function App() {
  return (
    <div className="min-h-screen scroll-smooth bg-white text-gray-900">
      <Header />
      <Hero onPlan={() => {
        const el = document.getElementById("book");
        if (el) el.scrollIntoView({ behavior: "smooth" });
      }} />
      <HowItWorks />
      <Destinations />
      <Guides />
      <Pricing />
      <Safety />
      <Reviews />
      <Faq />
      <BookingForm />
      <Legal />
      <div className="fixed bottom-4 right-4">
        <a href={encodeWhatsApp("Hi! I’d like to plan a trip.")} target="_blank" rel="noreferrer" className="rounded-full bg-emerald-700 px-5 py-3 text-sm font-semibold text-white shadow-lg hover:bg-emerald-800">Chat on WhatsApp</a>
      </div>
    </div>
  );
}
